var class_t_p___aviation_______simulation_1_1_client =
[
    [ "Client", "class_t_p___aviation_______simulation_1_1_client.html#ad488804486bf9ac34a40f99732de2b77", null ],
    [ "m_nom", "class_t_p___aviation_______simulation_1_1_client.html#a4fc06378ad59cf610d0eda298ab11532", null ],
    [ "Destination", "class_t_p___aviation_______simulation_1_1_client.html#a5485d4e38b886b8de7171f854d77a99e", null ],
    [ "Nom", "class_t_p___aviation_______simulation_1_1_client.html#ac9e29068c6c15bb301814db54c880712", null ],
    [ "Poid", "class_t_p___aviation_______simulation_1_1_client.html#a66921ed2d3c149ce43d410eb22e52521", null ],
    [ "PosX", "class_t_p___aviation_______simulation_1_1_client.html#ae61f99b18948d24499d458a6ec8f570d", null ],
    [ "PosY", "class_t_p___aviation_______simulation_1_1_client.html#a990b04978f14c3c2848fdeb3bb05b60f", null ],
    [ "Quantite", "class_t_p___aviation_______simulation_1_1_client.html#ac83c3a71648b5422029dc442c27a2912", null ]
];