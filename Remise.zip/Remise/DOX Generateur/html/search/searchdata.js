var indexSectionsWithContent =
{
  0: "abcdgilmnpstu",
  1: "acdgpstu",
  2: "t",
  3: "acdgpstu",
  4: "abcdgilmpstu",
  5: "bcglmpstu",
  6: "gmnt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Properties"
};

